from django.contrib import admin
from homepage.models import post

admin.site.register(post)
# Register your models here.
